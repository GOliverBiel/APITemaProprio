const express = require('express');

const BikesController = require('./controllers/BikesController');

const routes = express.Router();

const bikesController = new BikesController();

routes.get('/bikes', bikesController.index);
routes.post('/bikes', bikesController.create);

module.exports = routes;
