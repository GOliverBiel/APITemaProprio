const db = require('../database/connection');

module.exports = class BikesController {
  async index(request, response) {
    const bikes = await db('bikes').select('*');

    response.json(bikes);
  }

  async create(request, response) {
    const {
      name,
      model,
      description,
    } = request.body;

    const bike = {
      name,
      model,
      description,
    };

    const [insertedId] = await db('bikes').insert(bike);

    return response.json({
      id: insertedId,
      ...bike,
    });
  }
}
