export async function up(knex) {
  return knex.schema.createTable('bikes', table => {
    table.increments('id').primary();
    table.string('name').notNullable();
    table.string('model').notNullable();
    table.string('description').notNullable();
  })
}

export async function down(knex) {
  return knex.schema.dropTable('bikes');
}
